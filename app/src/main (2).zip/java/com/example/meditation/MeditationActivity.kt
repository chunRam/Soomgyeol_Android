package com.example.meditation

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MeditationActivity : AppCompatActivity() {

    private var meditationDurationMillis: Long = 0L
    private var remainingSeconds: Long = 0L
    private var countDownTimer: CountDownTimer? = null

    // 🎵 음악 관련 변수
    private lateinit var selectMusicButton: Button
    private var selectedMusic: String? = null
    private var mediaPlayer: MediaPlayer? = null
    private val MUSIC_REQUEST_CODE = 1001

    private lateinit var selectedMusicText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meditation)

        resetMeditationStats()

        meditationDurationMillis = intent.getLongExtra("durationMillis", 5 * 60 * 1000L)
        remainingSeconds = meditationDurationMillis / 1000

        val timerText = findViewById<TextView>(R.id.txtTimer)
        val endButton = findViewById<Button>(R.id.btnEnd)
        selectMusicButton = findViewById(R.id.btnSelectMusic)

        selectedMusicText = findViewById(R.id.txtSelectedMusic)

        // 🎵 음악 선택 버튼 클릭
        selectMusicButton.setOnClickListener {
            val intent = Intent(this, MusicSelectionActivity::class.java)
            startActivityForResult(intent, MUSIC_REQUEST_CODE)
        }

        // ⏱️ 명상 타이머 시작
        countDownTimer = object : CountDownTimer(meditationDurationMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                remainingSeconds = millisUntilFinished / 1000
                val minutes = remainingSeconds / 60
                val seconds = remainingSeconds % 60
                timerText.text = String.format("%d:%02d", minutes, seconds)
            }

            override fun onFinish() {
                stopMusic() // ⏹️ 음악 중지
                saveMeditationRecord(meditationDurationMillis / 1000)
                moveToJournal()
            }
        }.start()

        // 🔘 명상 중간 종료
        endButton.setOnClickListener {
            countDownTimer?.cancel()
            stopMusic()

            val elapsedSeconds = (meditationDurationMillis / 1000) - remainingSeconds
            if (elapsedSeconds >= 30) {
                saveMeditationRecord(elapsedSeconds)
            }

            AlertDialog.Builder(this)
                .setTitle("명상을 종료하시겠어요?")
                .setMessage("명상일기를 작성하시겠습니까?")
                .setPositiveButton("명상일기 작성") { _, _ -> moveToJournal() }
                .setNegativeButton("홈으로 돌아가기") { _, _ -> moveToHome() }
                .show()
        }

        // 🎵 음악 자동 재생
        selectedMusic = intent.getStringExtra("selected_music")
        selectedMusic?.let { playMusic(it) }
    }

    // 🎵 음악 재생
    private fun playMusic(fileName: String) {
        val resId = resources.getIdentifier(fileName, "raw", packageName)
        mediaPlayer = MediaPlayer.create(this, resId)
        mediaPlayer?.isLooping = true
        mediaPlayer?.start()
    }

    // 🎵 음악 정지
    private fun stopMusic() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
    }

    // 🎵 선택된 음악 결과 받기
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MUSIC_REQUEST_CODE && resultCode == RESULT_OK) {
            selectedMusic = data?.getStringExtra("selected_music")
            val displayName = data?.getStringExtra("display_name") ?: "알 수 없음"

            selectedMusicText.text = "선택된 음악: $displayName"

            // ✨ 애니메이션 (페이드인)
            selectedMusicText.alpha = 0f
            selectedMusicText.animate()
                .alpha(1f)
                .setDuration(500)
                .start()
        }
    }
    // 📝 명상일지 화면으로 이동
    private fun moveToJournal() {
        val intent = Intent(this, JournalActivity::class.java)
        startActivity(intent)
        finish()
    }

    // 🏠 홈 화면으로 이동
    private fun moveToHome() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }

    // 📌 SharedPreferences에 명상 기록 저장
    private fun saveMeditationRecord(duration: Long) {
        val prefs = getSharedPreferences("MeditationStats", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        val sessionCount = prefs.getInt("session_count", 0) + 1
        val totalTime = prefs.getLong("total_time", 0L) + duration
        editor.putInt("session_count", sessionCount)
        editor.putLong("total_time", totalTime)
        editor.apply()
    }

    // 🔄 초기화
    private fun resetMeditationStats() {
        val prefs = getSharedPreferences("MeditationStats", Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopMusic()
        countDownTimer?.cancel()
    }
}
