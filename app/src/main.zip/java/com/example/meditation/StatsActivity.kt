package com.example.meditation

import android.content.Context
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StatsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)

        val prefs = getSharedPreferences("MeditationStats", Context.MODE_PRIVATE)

        val totalSessions = prefs.getInt("total_sessions", 0)
        val totalTimeMillis = prefs.getLong("total_time", 0L)
        val totalMinutes = totalTimeMillis / 1000 / 60  // 초 → 분 변환

        // 화면 요소에 값 반영
        val sessionsText = findViewById<TextView>(R.id.txtTotalSessions)
        val timeText = findViewById<TextView>(R.id.txtTotalTime)

        sessionsText.text = "총 명상 횟수: ${totalSessions}회"
        timeText.text = "총 명상 시간: ${totalMinutes}분"
    }
}
