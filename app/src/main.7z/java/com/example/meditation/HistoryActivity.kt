package com.example.meditation

import android.content.Context
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class HistoryActivity : AppCompatActivity() {

    private val dateFormat = SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val statsText = findViewById<TextView>(R.id.txtStats)
        val journalText = findViewById<TextView>(R.id.txtJournals)

        // 📊 통계 불러오기
        val prefsStats = getSharedPreferences("MeditationStats", Context.MODE_PRIVATE)
        val sessionCount = prefsStats.getInt("session_count", 0)
        val totalTime = prefsStats.getLong("total_time", 0L)
        val totalMinutes = totalTime / 60

        statsText.text = "총 명상 횟수: $sessionCount 회\n총 명상 시간: $totalMinutes 분"

        // 📖 감정일지 불러오기
        val prefsJournal = getSharedPreferences("MeditationJournal", Context.MODE_PRIVATE)
        val allJournals = prefsJournal.all.toSortedMap()

        val journalBuilder = StringBuilder()
        for ((key, value) in allJournals.entries.reversed()) {
            if (key.startsWith("journal_")) {
                journalBuilder.append("🕓 ${formatTimestamp(key)}\n$value\n\n")
            }
        }

        journalText.text = journalBuilder.toString().ifEmpty { "작성된 일지가 없습니다." }
    }

    // ⏱️ 타임스탬프를 날짜 문자열로 포맷
    private fun formatTimestamp(key: String): String {
        return try {
            val timestamp = key.removePrefix("journal_").toLong()
            dateFormat.format(Date(timestamp))
        } catch (e: Exception) {
            key
        }
    }
}
