package com.example.meditation

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class ContentActivity : AppCompatActivity() {

    private val timeMap = mapOf(
        "1분" to 1 * 60 * 1000L,
        "3분" to 3 * 60 * 1000L,
        "5분" to 5 * 60 * 1000L,
        "10분" to 10 * 60 * 1000L
    )

    private val meditationTips = listOf(
        "편안한 자세로 등을 곧게 펴고 앉아보세요.",
        "눈을 감고 호흡에 집중해보세요.",
        "떠오르는 생각을 판단하지 말고 그냥 흘려보내세요.",
        "명상 중에는 아무것도 하지 않아도 괜찮아요.",
        "조용한 공간에서 3분만 나에게 집중해보세요."
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_content)

        val emotion = intent.getStringExtra("emotion") ?: "unknown"

        val layout = findViewById<LinearLayout>(R.id.contentLayout)
        val txtMessage = findViewById<TextView>(R.id.txtEmotionMessage)
        val btnStart = findViewById<Button>(R.id.btnStartMeditation)
        val btnBack = findViewById<Button>(R.id.btnBackToEmotion)
        val spinner = findViewById<Spinner>(R.id.spinnerTime)

        val timeOptions = timeMap.keys.toList()
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, timeOptions)
        spinner.adapter = adapter

        applyEmotionUI(emotion, layout, txtMessage)

        val defaultSelection = when (emotion) {
            "happy" -> timeOptions.indexOf("3분")
            "neutral" -> timeOptions.indexOf("5분")
            "sad" -> timeOptions.indexOf("10분")
            else -> 0
        }
        if (defaultSelection >= 0) spinner.setSelection(defaultSelection)

        btnStart.setOnClickListener {
            val selectedTime = spinner.selectedItem?.toString()
            if (selectedTime.isNullOrBlank()) {
                Toast.makeText(this, "명상 시간을 선택해주세요", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val duration = timeMap[selectedTime] ?: 1 * 60 * 1000L
            val prefs = getSharedPreferences("MeditationPrefs", MODE_PRIVATE)
            val hasSeenTip = prefs.getBoolean("has_seen_tip", false)

            if (hasSeenTip) {
                startMeditation(emotion, duration)
            } else {
                val randomTip = meditationTips.random()
                AlertDialog.Builder(this)
                    .setTitle("명상 팁")
                    .setMessage("🧘 ${randomTip}\n\n준비되셨다면 '시작하기'를 눌러주세요.")
                    .setPositiveButton("시작하기") { _, _ ->
                        prefs.edit().putBoolean("has_seen_tip", true).apply()
                        startMeditation(emotion, duration)
                    }
                    .setNegativeButton("취소", null)
                    .show()
            }
        }

        btnBack.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
    }

    private fun startMeditation(emotion: String, duration: Long) {
        val intent = Intent(this, MeditationActivity::class.java)
        intent.putExtra("emotion", emotion)
        intent.putExtra("durationMillis", duration)
        startActivity(intent)
    }

    private fun applyEmotionUI(emotion: String, layout: LinearLayout, txtMessage: TextView) {
        when (emotion) {
            "happy" -> {
                layout.setBackgroundColor(Color.parseColor("#FFF9C4"))
                txtMessage.text = "기쁜 하루네요 😊\n당신의 웃음이 모두에게 전해지길!"
            }
            "neutral" -> {
                layout.setBackgroundColor(Color.parseColor("#E0F2F1"))
                txtMessage.text = "차분한 하루군요 😌\n숨을 고르고 나를 바라보는 시간이에요."
            }
            "sad" -> {
                layout.setBackgroundColor(Color.parseColor("#F8BBD0"))
                txtMessage.text = "마음이 무거운 날이네요 😢\n잠시 나를 위한 시간을 가져봐요."
            }
            else -> {
                layout.setBackgroundColor(Color.LTGRAY)
                txtMessage.text = "감정을 알 수 없어요.\n다시 선택해주세요."
            }
        }
    }
}
