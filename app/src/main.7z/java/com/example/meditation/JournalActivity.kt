package com.example.meditation

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class JournalActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_journal)

        val journalEditText = findViewById<EditText>(R.id.edtJournal)
        val saveButton = findViewById<Button>(R.id.btnSaveJournal)

        saveButton.setOnClickListener {
            val journalText = journalEditText.text.toString().trim()

            if (journalText.isEmpty()) {
                Toast.makeText(this, "내용을 입력해주세요", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 📌 SharedPreferences 에 감정일지 저장
            val prefs = getSharedPreferences("MeditationJournal", Context.MODE_PRIVATE)
            val editor = prefs.edit()
            val timestamp = System.currentTimeMillis()
            editor.putString("journal_$timestamp", journalText)
            editor.apply()

            Toast.makeText(this, "기록이 저장되었습니다", Toast.LENGTH_SHORT).show()

            // 홈으로 이동
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
