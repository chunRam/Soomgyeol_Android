package com.example.meditation

import com.google.firebase.Timestamp

data class JournalEntry(
    val content: String = "",
    val emotion: String? = null,
    val timestamp: Timestamp? = null,
    val duration_minutes: Int = 0
)
