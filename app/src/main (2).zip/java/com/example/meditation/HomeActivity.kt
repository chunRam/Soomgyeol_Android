package com.example.meditation

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        findViewById<Button>(R.id.btnHappy).setOnClickListener {
            moveToContent("happy")
        }
        findViewById<Button>(R.id.btnNeutral).setOnClickListener {
            moveToContent("neutral")
        }
        findViewById<Button>(R.id.btnSad).setOnClickListener {
            moveToContent("sad")
        }

        findViewById<Button>(R.id.btnStats).setOnClickListener {
            startActivity(Intent(this, StatsActivity::class.java))
        }

        findViewById<Button>(R.id.btnRecord).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        // ✅ 팁 초기화 버튼
        findViewById<Button>(R.id.btnResetTips).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("명상 팁 초기화")
                .setMessage("명상 시작 전에 다시 팁을 보시겠어요?")
                .setPositiveButton("초기화") { _, _ ->
                    val prefs = getSharedPreferences("MeditationPrefs", MODE_PRIVATE)
                    prefs.edit().putBoolean("has_seen_tip", false).apply()
                    Toast.makeText(this, "팁 보기 설정이 초기화되었습니다", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("취소", null)
                .show()
        }

        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

    }

    private fun moveToContent(emotion: String) {
        val intent = Intent(this, ContentActivity::class.java)
        intent.putExtra("emotion", emotion)
        startActivity(intent)
    }
}
