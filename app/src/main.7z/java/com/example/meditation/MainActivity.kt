package com.example.meditation

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

// 앱 실행 시 처음 진입하는 Activity. 로그인 화면으로 바로 이동만 담당함.
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // LoginActivity로 바로 이동
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)

        // MainActivity는 백스택에서 제거 (뒤로가기 눌러도 다시 안 옴)
        finish()
    }
}
