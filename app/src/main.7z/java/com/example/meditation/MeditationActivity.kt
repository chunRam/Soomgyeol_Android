package com.example.meditation

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MeditationActivity : AppCompatActivity() {

    private var meditationDurationMillis: Long = 0L
    private var remainingSeconds: Long = 0L
    private var countDownTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meditation)

        resetMeditationStats()
        // 🔸 전달받은 타이머 시간 (기본 5분)
        meditationDurationMillis = intent.getLongExtra("durationMillis", 5 * 60 * 1000L)
        remainingSeconds = meditationDurationMillis / 1000

        val timerText = findViewById<TextView>(R.id.txtTimer)
        val endButton = findViewById<Button>(R.id.btnEndMeditation)

        // ⏱️ 명상 타이머 시작
        countDownTimer = object : CountDownTimer(meditationDurationMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                remainingSeconds = millisUntilFinished / 1000
                val minutes = remainingSeconds / 60
                val seconds = remainingSeconds % 60
                timerText.text = String.format("%d:%02d", minutes, seconds)
            }

            override fun onFinish() {
                // ✅ 종료까지 완료된 경우, 초 단위로 저장
                saveMeditationRecord(meditationDurationMillis / 1000)
                moveToJournal()
            }
        }.start()

        // 🔘 명상 중간 종료 시 다이얼로그 표시
        endButton.setOnClickListener {
            countDownTimer?.cancel()
            val elapsedSeconds = (meditationDurationMillis / 1000) - remainingSeconds

            // ✅ 30초 이상 수행한 경우만 저장
            if (elapsedSeconds >= 30) {
                saveMeditationRecord(elapsedSeconds)
            }

            AlertDialog.Builder(this)
                .setTitle("명상을 종료하시겠어요?")
                .setMessage("명상일기를 작성하시겠습니까?")
                .setPositiveButton("명상일기 작성") { _, _ ->
                    moveToJournal()
                }
                .setNegativeButton("홈으로 돌아가기") { _, _ ->
                    moveToHome()
                }
                .show()
        }
    }

    // 📝 명상일지 화면으로 이동
    private fun moveToJournal() {
        val intent = Intent(this, JournalActivity::class.java)
        startActivity(intent)
        finish()
    }

    // 🏠 홈 화면으로 이동
    private fun moveToHome() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }

    // 📌 SharedPreferences에 명상 기록 저장 (단위: 초)
    private fun saveMeditationRecord(duration: Long) {
        val prefs = getSharedPreferences("MeditationStats", Context.MODE_PRIVATE)
        val editor = prefs.edit()

        val sessionCount = prefs.getInt("session_count", 0) + 1
        val totalTime = prefs.getLong("total_time", 0L) + duration // ✅ 누적 초 단위

        editor.putInt("session_count", sessionCount)
        editor.putLong("total_time", totalTime) // ✅ 그대로 저장
        editor.apply()
    }

    private fun resetMeditationStats() {
        val prefs = getSharedPreferences("MeditationStats", Context.MODE_PRIVATE)
        prefs.edit().clear().apply()  // 저장된 전체 값을 삭제
    }
}
