package com.example.meditation

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class JournalActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_journal)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val journalEditText = findViewById<EditText>(R.id.edtJournal)
        val saveButton = findViewById<Button>(R.id.btnSaveJournal)

        saveButton.setOnClickListener {
            val journalText = journalEditText.text.toString().trim()

            if (journalText.isEmpty()) {
                Toast.makeText(this, "내용을 입력해주세요", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val uid = auth.currentUser?.uid
            if (uid == null) {
                Toast.makeText(this, "로그인이 필요합니다.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 저장할 일기 데이터 구성
            val duration = intent.getIntExtra("duration_minutes", 10)

            val journalData = hashMapOf(
                "content" to journalText,
                "timestamp" to FieldValue.serverTimestamp(),
                "duration_minutes" to duration  // ✅ 전달된 명상 시간 저장
            )

            db.collection("users").document(uid).collection("journals")
                .add(journalData)
                .addOnSuccessListener {
                    Toast.makeText(this, "기록이 저장되었습니다", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, HomeActivity::class.java))
                    finish()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "저장 실패: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
        }
    }
}
